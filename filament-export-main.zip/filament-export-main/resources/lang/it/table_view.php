<?php

return [
    'preview_modal_heading' => 'Anteprima',
    'print_action_label' => 'Stampa',
    'export_action_label' => 'Esporta',
];
