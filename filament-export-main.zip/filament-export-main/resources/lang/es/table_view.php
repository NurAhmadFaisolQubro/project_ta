<?php

return [
    'preview_modal_heading' => 'Vista previa',
    'print_action_label' => 'Imprimir',
    'export_action_label' => 'Exportar',
];
