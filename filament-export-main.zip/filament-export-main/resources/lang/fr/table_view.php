<?php

return [
    'preview_modal_heading' => 'Prévisualisation',
    'print_action_label' => 'Imprimer',
    'export_action_label' => 'Exporter',
];
