<?php

return [
    'preview_modal_heading' => 'Önizleme',
    'print_action_label' => 'Yazdır',
    'export_action_label' => 'Dışarı Aktar',
];
