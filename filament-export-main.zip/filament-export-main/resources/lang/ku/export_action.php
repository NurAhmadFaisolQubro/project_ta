<?php

return [
    'action_label' => 'ڕاپۆڕت',
    'modal_heading' => 'ڕاپۆڕت',
    'file_name_field_label' => 'ناوی فایل',
    'format_field_label' => 'جۆر',
    'page_orientation_field_label' => 'ئاڕاستەی پەڕە',
    'filter_columns_field_label' => 'فلتەری خانەکان',
    'additional_columns_field' => [
        'label' => 'خانەی زیادە',
        'title_field_label' => 'ناوی خانە',
        'default_value_field_label' => 'نرخی خانە',
        'add_button_label' => 'زیادکردنی خانە',
    ],
    'export_action_label' => 'دابەزاندن',
    'print_action_label' => 'چاپکردن',
    'preview_action_label' => 'بینین',
    'cancel_action_label' => 'ڕەتکردنەوە',
    'page_orientation_portrait' => 'پەڕگەی ستوونی',
    'page_orientation_landscape' => 'پەڕگەی ئاسۆیی',
];
