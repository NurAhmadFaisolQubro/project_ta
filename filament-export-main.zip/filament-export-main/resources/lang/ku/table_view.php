<?php

return [
    'preview_modal_heading' => 'بینین',
    'print_action_label' => 'چاپکردن',
    'export_action_label' => 'دابەزاندن',
];
