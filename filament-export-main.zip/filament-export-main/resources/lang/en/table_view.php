<?php

return [
    'preview_modal_heading' => 'Preview',
    'print_action_label' => 'Print',
    'export_action_label' => 'Export',
];
