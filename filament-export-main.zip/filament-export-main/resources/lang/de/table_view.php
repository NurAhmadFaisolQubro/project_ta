<?php

return [
    'preview_modal_heading' => 'Vorschau',
    'print_action_label' => 'Drucken',
    'export_action_label' => 'Exportieren',
];
